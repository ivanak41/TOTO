using System.Text;
using HtmlAgilityPack;
using Toto.Models;
using Toto.Parsers;

namespace Toto.Services;

public static class DataLoader
{
    // ── Configuration flag ───────────────────────────────────────────
    // Set to true  → always use local files in res/draws/ (no internet)
    // Set to false → try to download from the live website first;
    //                fall back to local files on any network error;
    public static bool UseLocalFiles { get; set; } = false;

    private const string StatsPageUrl = "https://info.toto.bg/statistika/6x49";

    // Resolve res/ relative to the executable location
    private static readonly string ResDrawsDir =
        Path.Combine(AppContext.BaseDirectory, "res", "draws");

    public static async Task<IEnumerable<Draw>> LoadAllDrawsAsync()
    {
        string html = await LoadHtmlAsync();
        var links = ParseLinks(html);

        var allDraws = new List<Draw>();

        foreach (var (year, url) in links)
        {
            try
            {
                var draws = await LoadYearAsync(year, url);
                allDraws.AddRange(draws);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"[Предупреждение] Грешка при зареждане на {year}: {ex.Message}");
            }
        }

        return allDraws;
    }

    // ──────────────────────────────────────────────────────────────
    // HTML loading
    // ──────────────────────────────────────────────────────────────
    private static async Task<string> LoadHtmlAsync()
    {
        if (!UseLocalFiles)
        {
            try
            {
                using var client = CreateHttpClient();
                return await client.GetStringAsync(StatsPageUrl);
            }
            catch
            {
                Console.Error.WriteLine("[Предупреждение] Уебсайтът е недостъпен. Използват се локални файлове.");
            }
        }

        string localHtml = Path.Combine(AppContext.BaseDirectory, "res", "toto.html");
        return await File.ReadAllTextAsync(localHtml, Encoding.UTF8);
    }

    // ──────────────────────────────────────────────────────────────
    // Link parsing with HtmlAgilityPack
    // ──────────────────────────────────────────────────────────────
    private static List<(int year, string url)> ParseLinks(string html)
    {
        var doc = new HtmlDocument();
        doc.LoadHtml(html);

        var results = new List<(int, string)>();

        // Debug: Check the HTML content
        Console.Error.WriteLine($"[Debug] HTML length: {html.Length} characters");

        // Check for CAPTCHA detection
        if (html.Contains("captcha", StringComparison.OrdinalIgnoreCase) || 
            html.Contains("Radware", StringComparison.OrdinalIgnoreCase))
        {
            Console.Error.WriteLine("[Warning] CAPTCHA page detected! The website is blocking automated requests.");
            Console.Error.WriteLine("[Info] Consider using UseLocalFiles = true or adding delays between requests.");
        }

        Console.Error.WriteLine($"[Debug] DocumentNode.ChildNodes count: {doc.DocumentNode?.ChildNodes.Count ?? 0}");

        // Get all <a> tags using XPath
        var allAnchorNodes = doc.DocumentNode.SelectNodes("//a");

        if (allAnchorNodes == null)
        {
            Console.Error.WriteLine("[Debug] XPath '//a' returned null, trying Descendants...");
            // Try alternative: get nodes by tag name using Descendants
            var anchorsManual = doc.DocumentNode.Descendants("a").ToList();
            Console.Error.WriteLine($"[Debug] Anchor tags found via Descendants: {anchorsManual.Count}");

            if (anchorsManual.Any())
            {
                foreach (var node in anchorsManual)
                {
                    string innerText = node.InnerText.Trim();
                    string href = node.GetAttributeValue("href", "");

                    // Only process links whose visible text is a 4-digit year (1958-2025)
                    if (!int.TryParse(innerText, out int year)) continue;
                    if (year < 1958 || year > 2100) continue;
                    if (string.IsNullOrWhiteSpace(href)) continue;

                    results.Add((year, href));
                }
            }
        }
        else
        {
            Console.Error.WriteLine($"[Debug] Total <a> tags found: {allAnchorNodes.Count}");

            // Filter to only those with href attribute
            var nodesWithHref = allAnchorNodes
                .Where(node => node.Attributes.Contains("href") && !string.IsNullOrWhiteSpace(node.GetAttributeValue("href", "")))
                .ToList();

            Console.Error.WriteLine($"[Debug] <a> tags with href found: {nodesWithHref.Count}");

            foreach (var node in nodesWithHref)
            {
                string innerText = node.InnerText.Trim();
                string href = node.GetAttributeValue("href", "");

                // Only process links whose visible text is a 4-digit year (1958-2025)
                if (!int.TryParse(innerText, out int year)) continue;
                if (year < 1958 || year > 2100) continue;
                if (string.IsNullOrWhiteSpace(href)) continue;

                results.Add((year, href));
            }
        }

        Console.Error.WriteLine($"[Debug] Final parsed results: {results.Count} years found");

        // Sort ascending by year; deduplicate (keep last seen, which is the most specific)
        return results
            .GroupBy(x => x.Item1)
            .Select(g => g.Last())
            .OrderBy(x => x.Item1)
            .ToList();
    }

    // ──────────────────────────────────────────────────────────────
    // Per-year file loading
    // ──────────────────────────────────────────────────────────────
    private static async Task<IEnumerable<Draw>> LoadYearAsync(int year, string url)
    {
        bool isDocx = url.EndsWith(".docx", StringComparison.OrdinalIgnoreCase);
        string ext = isDocx ? ".docx" : ".txt";
        string localPath = Path.Combine(ResDrawsDir, $"{year}{ext}");

        Stream? stream = null;

        if (!UseLocalFiles)
        {
            try
            {
                using var client = CreateHttpClient();
                var bytes = await client.GetByteArrayAsync(url);
                stream = new MemoryStream(bytes);
            }
            catch
            {
                // Fall through to local file
            }
        }

        if (stream is null)
        {
            if (!File.Exists(localPath))
                return Enumerable.Empty<Draw>();

            stream = File.OpenRead(localPath);
        }

        using (stream)
        {
            if (isDocx)
                return DocxParser.Parse(stream, year).ToList();

            using var reader = new StreamReader(stream, Encoding.UTF8,
                detectEncodingFromByteOrderMarks: true);
            string content = await reader.ReadToEndAsync();
            return TxtParser.Parse(content, year).ToList();
        }
    }

    private static HttpClient CreateHttpClient()
    {
        var client = new HttpClient(new SocketsHttpHandler
        {
            AutomaticDecompression = System.Net.DecompressionMethods.GZip | System.Net.DecompressionMethods.Deflate
        })
        {
            Timeout = TimeSpan.FromSeconds(15)
        };

        // Add comprehensive headers to mimic a real browser and bypass bot detection
        client.DefaultRequestHeaders.Add("User-Agent",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        client.DefaultRequestHeaders.Add("Accept",
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");
        client.DefaultRequestHeaders.Add("Accept-Language", "en-US,en;q=0.9");
        client.DefaultRequestHeaders.Add("Accept-Encoding", "gzip, deflate, br");
        client.DefaultRequestHeaders.Add("Cache-Control", "max-age=0");
        client.DefaultRequestHeaders.Add("Sec-Fetch-Dest", "document");
        client.DefaultRequestHeaders.Add("Sec-Fetch-Mode", "navigate");
        client.DefaultRequestHeaders.Add("Sec-Fetch-Site", "none");
        client.DefaultRequestHeaders.Add("Upgrade-Insecure-Requests", "1");
        client.DefaultRequestHeaders.Add("Sec-Ch-Ua", "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\"");
        client.DefaultRequestHeaders.Add("Sec-Ch-Ua-Mobile", "?0");
        client.DefaultRequestHeaders.Add("Sec-Ch-Ua-Platform", "\"Windows\"");

        return client;
    }
}
