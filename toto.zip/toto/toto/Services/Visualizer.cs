using Toto.Models;

namespace Toto.Services;

public static class Visualizer
{
    private const int BarMaxWidth = 40;

    // ── Horizontal bar chart ─────────────────────────────────────
    // data: Dictionary<number, count> already sorted as desired
    public static void ShowBarChart(string title, Dictionary<int, int> data)
    {
        Console.WriteLine();
        Console.WriteLine(title);
        Console.WriteLine(new string('-', 60));

        if (data.Count == 0)
        {
            Console.WriteLine("  (няма данни)");
            return;
        }

        int maxCount = data.Values.Max();
        int labelWidth = data.Keys.Max().ToString().Length;
        int countWidth = maxCount.ToString().Length;

        foreach (var (num, count) in data)
        {
            int barLen = maxCount == 0 ? 0 : (int)Math.Round((double)count / maxCount * BarMaxWidth);
            string bar = new('#', barLen);
            string padding = new(' ', BarMaxWidth - barLen);

            Console.WriteLine($"  {num.ToString().PadLeft(labelWidth)} | {bar}{padding} {count.ToString().PadLeft(countWidth)}");
        }

        Console.WriteLine();
    }

    // ── 7×7 Heat Map ─────────────────────────────────────────────
    // Colours numbers 1-49 by frequency tier:
    //   Top 30%    → ConsoleColor.Red    (hot)
    //   Middle 40% → ConsoleColor.Yellow (neutral)
    //   Bottom 30% → ConsoleColor.Cyan   (cold)
    public static void ShowHeatMap(Dictionary<int, int> frequencies, string title)
    {
        Console.WriteLine();
        Console.WriteLine(title);
        Console.WriteLine(new string('-', 60));
        Console.WriteLine("  Топлинна карта (червено=горещо, жълто=неутрално, синьо=студено)");
        Console.WriteLine();

        // Sort all 49 possible numbers by frequency to determine tiers
        var allNums = Enumerable.Range(1, 49).ToList();
        var sorted = allNums
            .OrderBy(n => frequencies.GetValueOrDefault(n, 0))
            .ToList();

        int total = sorted.Count; // 49
        int bottomCount = (int)Math.Round(total * 0.30);
        int topCount = (int)Math.Round(total * 0.30);

        var bottomSet = sorted.Take(bottomCount).ToHashSet();
        var topSet = sorted.TakeLast(topCount).ToHashSet();
        // middle = everything else

        Console.Write("  ");
        for (int n = 1; n <= 49; n++)
        {
            int col = (n - 1) % 7;

            if (col == 0 && n > 1)
            {
                Console.WriteLine();
                Console.Write("  ");
            }

            ConsoleColor color = topSet.Contains(n)
                ? ConsoleColor.Red
                : bottomSet.Contains(n)
                    ? ConsoleColor.Cyan
                    : ConsoleColor.Yellow;

            Console.ForegroundColor = color;
            Console.Write($"{n,3}");
            Console.ResetColor();
        }

        Console.WriteLine();
        Console.WriteLine();

        // Legend
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("  ### ");
        Console.ResetColor();
        Console.Write("Горещи (топ 30%)   ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("### ");
        Console.ResetColor();
        Console.Write("Неутрални (40%)   ");
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write("### ");
        Console.ResetColor();
        Console.WriteLine("Студени (долни 30%)");
        Console.WriteLine();
    }

    // ── Decade distribution bar chart ────────────────────────────
    public static void ShowDecadeDistribution(Dictionary<string, int> data, string title)
    {
        Console.WriteLine();
        Console.WriteLine(title);
        Console.WriteLine(new string('-', 60));

        if (data.Count == 0)
        {
            Console.WriteLine("  (няма данни)");
            return;
        }

        int maxCount = data.Values.Max();
        int countWidth = maxCount.ToString().Length;

        foreach (var (label, count) in data)
        {
            int barLen = maxCount == 0 ? 0 : (int)Math.Round((double)count / maxCount * BarMaxWidth);
            string bar = new('#', barLen);
            string padding = new(' ', BarMaxWidth - barLen);

            Console.WriteLine($"  {label.PadLeft(5)} | {bar}{padding} {count.ToString().PadLeft(countWidth)}");
        }

        Console.WriteLine();
    }

    // ── Hot pairs list ────────────────────────────────────────────
    public static void ShowHotPairs(IEnumerable<(int Num1, int Num2, int Count)> pairs, string title)
    {
        Console.WriteLine();
        Console.WriteLine(title);
        Console.WriteLine(new string('-', 60));

        int rank = 1;
        bool any = false;
        foreach (var (a, b, count) in pairs)
        {
            Console.WriteLine($"  {rank,3}. ({a,2}, {b,2})  →  {count} съвместни тегления");
            rank++;
            any = true;
        }

        if (!any) Console.WriteLine("  (няма данни)");
        Console.WriteLine();
    }
}
