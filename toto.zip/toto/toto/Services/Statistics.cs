using Toto.Models;

namespace Toto.Services;

public static class Statistics
{
    // ── Top N most-frequent numbers ──────────────────────────────
    // Returns Dictionary<number, count> sorted descending by count.
    public static Dictionary<int, int> GetTopNNumbers(IEnumerable<Draw> draws, int n) =>
        draws
            .SelectMany(d => d.Numbers)
            .GroupBy(num => num)
            .OrderByDescending(g => g.Count())
            .Take(n)
            .ToDictionary(g => g.Key, g => g.Count());

    // ── Hot pairs ────────────────────────────────────────────────
    // Returns the top N pairs (num1, num2, coOccurrenceCount),
    // where num1 < num2, sorted descending by count.
    public static IEnumerable<(int Num1, int Num2, int Count)> GetHotPairs(
        IEnumerable<Draw> draws, int n) =>
        draws
            .SelectMany(d =>
                from i in Enumerable.Range(0, d.Numbers.Length)
                from j in Enumerable.Range(i + 1, d.Numbers.Length - i - 1)
                let a = Math.Min(d.Numbers[i], d.Numbers[j])
                let b = Math.Max(d.Numbers[i], d.Numbers[j])
                select (a, b))
            .GroupBy(p => p)
            .OrderByDescending(g => g.Count())
            .Take(n)
            .Select(g => (g.Key.Item1, g.Key.Item2, g.Count()));

    // ── Distribution by decade ───────────────────────────────────
    // Buckets: 1-10, 11-20, 21-30, 31-40, 41-49
    // Returns Dictionary<label, count> ordered by range start.
    public static Dictionary<string, int> GetDecadeDistribution(IEnumerable<Draw> draws)
    {
        var buckets = new (int lo, int hi, string label)[]
        {
            (1,  10, "1-10"),
            (11, 20, "11-20"),
            (21, 30, "21-30"),
            (31, 40, "31-40"),
            (41, 49, "41-49"),
        };

        var allNumbers = draws.SelectMany(d => d.Numbers).ToList();

        return buckets.ToDictionary(
            b => b.label,
            b => allNumbers.Count(n => n >= b.lo && n <= b.hi));
    }
}
