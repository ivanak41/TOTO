using System.Text;
using System.Text.RegularExpressions;
using Toto.Models;

namespace Toto.Parsers;

public static class TxtParser
{
    // Matches: "Тираж   1/2020, Теглене 1: 8 18 27 45 47 49"
    private static readonly Regex VerboseLineRegex = new(
        @"Тираж\s+(\d+)/(\d+),\s*Теглене\s+\d+:\s+([\d\s]+)",
        RegexOptions.Compiled);

    private static readonly Regex DigitsRegex = new(@"\d+", RegexOptions.Compiled);

    public static IEnumerable<Draw> Parse(string content, int year)
    {
        var lines = content.Split('\n', StringSplitOptions.RemoveEmptyEntries);

        // Detect format: if any line starts with "Тираж" it's the verbose format
        bool isVerbose = lines.Any(l => l.TrimStart().StartsWith("Тираж"));

        return isVerbose
            ? ParseVerbose(lines, year)
            : ParseOldCompressed(lines, year);
    }

    // ──────────────────────────────────────────────────────────────
    // Verbose format: "Тираж N/YEAR, Теглене 1: N N N N N N"
    // ──────────────────────────────────────────────────────────────
    private static IEnumerable<Draw> ParseVerbose(string[] lines, int year)
    {
        foreach (var line in lines)
        {
            var m = VerboseLineRegex.Match(line);
            if (!m.Success) continue;

            if (!int.TryParse(m.Groups[1].Value, out int drawNum)) continue;

            var numbers = DigitsRegex.Matches(m.Groups[3].Value)
                .Select(x => int.Parse(x.Value))
                .Where(n => n >= 1 && n <= 49)
                .ToArray();

            if (numbers.Length == 6)
                yield return new Draw(year, drawNum, numbers);
        }
    }

    // ──────────────────────────────────────────────────────────────
    // Old compressed format (multiple sub-formats, all pre-2018)
    //
    // Detection/split rules per line:
    //   • Skip blank lines or lines with no digits
    //   • If line contains TABs  → split by one-or-more TABs
    //   • Else if line has 2+ consecutive spaces → split by \s{2,}
    //   • Else → single segment
    //
    // Per segment, extract all integers with \d+:
    //   • 1 integer  → draw index only, skip
    //   • 7 integers → first is draw index, skip it, take remaining 6
    //   • 6 integers, all 1-49 → lottery draw
    // ──────────────────────────────────────────────────────────────
    private static IEnumerable<Draw> ParseOldCompressed(string[] lines, int year)
    {
        int drawCounter = 0;

        foreach (var rawLine in lines)
        {
            string line = rawLine.TrimEnd('\r');

            // Skip lines that are purely non-numeric (headers, Cyrillic-only)
            if (!line.Any(char.IsDigit)) continue;

            string[] segments;
            if (line.Contains('\t'))
                segments = line.Split('\t', StringSplitOptions.RemoveEmptyEntries);
            else if (Regex.IsMatch(line, @"\s{2,}"))
                segments = Regex.Split(line.Trim(), @"\s{2,}");
            else
                segments = new[] { line };

            foreach (var seg in segments)
            {
                string trimmed = seg.Trim();
                if (trimmed.Length == 0) continue;

                var nums = DigitsRegex.Matches(trimmed)
                    .Select(m => int.Parse(m.Value))
                    .ToArray();

                int[] lottery;
                if (nums.Length == 1)
                {
                    // standalone draw index – skip
                    continue;
                }
                else if (nums.Length == 7)
                {
                    // first number is draw index, rest are lottery numbers
                    lottery = nums[1..];
                }
                else if (nums.Length == 6)
                {
                    lottery = nums;
                }
                else
                {
                    continue; // malformed
                }

                if (lottery.All(n => n >= 1 && n <= 49))
                    yield return new Draw(year, ++drawCounter, lottery);
            }
        }
    }
}
