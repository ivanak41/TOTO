using System.IO.Compression;
using System.Text;
using System.Xml.Linq;
using Toto.Models;
using Toto.Parsers;

namespace Toto.Parsers;

public static class DocxParser
{
    private static readonly XNamespace W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

    public static IEnumerable<Draw> Parse(Stream docxStream, int year)
    {
        string text = ExtractText(docxStream);
        return TxtParser.Parse(text, year);
    }

    private static string ExtractText(Stream stream)
    {
        using var zip = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: true);

        var entry = zip.GetEntry("word/document.xml");
        if (entry is null)
            return string.Empty;

        using var entryStream = entry.Open();
        var doc = XDocument.Load(entryStream);

        // Collect paragraphs: concatenate all <w:t> text within each <w:p>
        var sb = new StringBuilder();
        foreach (var para in doc.Descendants(W + "p"))
        {
            var paraText = string.Concat(
                para.Descendants(W + "t").Select(t => t.Value));
            sb.AppendLine(paraText);
        }

        return sb.ToString();
    }
}
