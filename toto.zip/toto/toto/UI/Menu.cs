using Toto.Models;
using Toto.Services;

namespace Toto.UI;

public class Menu
{
    private readonly IReadOnlyList<Draw> _allDraws;
    private IEnumerable<Draw>? _filtered;
    private int _fromYear;
    private int _toYear;

    public Menu(IEnumerable<Draw> allDraws)
    {
        _allDraws = allDraws.ToList();
    }

    public void Run()
    {
        while (true)
        {
            PrintHeader();

            string? input = Console.ReadLine()?.Trim();

            Console.Clear();

            switch (input)
            {
                case "1": SelectPeriod(); break;
                case "2": ShowTopNumbers(); break;
                case "3": ShowHotPairs(); break;
                case "4": ShowDecadeDistribution(); break;
                case "0": return;
                default:
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("  Невалиден избор. Въведете число от 0 до 4.");
                    Console.ResetColor();
                    WaitForKey();
                    break;
            }
        }
    }

    // ──────────────────────────────────────────────────────────────
    // Menu header
    // ──────────────────────────────────────────────────────────────
    private void PrintHeader()
    {
        int minYear = _allDraws.Count > 0 ? _allDraws.Min(d => d.Year) : 1958;
        int maxYear = _allDraws.Count > 0 ? _allDraws.Max(d => d.Year) : 2025;

        Console.WriteLine();
        Console.WriteLine("  ============================================");
        Console.WriteLine("              ТОТО АНАЛИЗАТОР");
        Console.WriteLine("  ============================================");

        if (_filtered is not null)
        {
            int count = _filtered.Count();
            Console.WriteLine($"   Избран период: {_fromYear}–{_toYear}  ({count} тиража)");
        }
        else
        {
            Console.WriteLine($"   Налични данни: {minYear}–{maxYear}  ({_allDraws.Count} тиража)");
        }

        Console.WriteLine("  ============================================");
        Console.WriteLine("   [1]  Избери период (от година - до година)");
        Console.WriteLine("   [2]  Топ N най-чести числа  + топлинна карта");
        Console.WriteLine("   [3]  Горещи двойки");
        Console.WriteLine("   [4]  Разпределение по десетици");
        Console.WriteLine();
        Console.WriteLine("   [0]  Изход");
        Console.WriteLine("  ============================================");
        Console.Write("   Избор: ");
    }

    // ──────────────────────────────────────────────────────────────
    // Option 1 – Select period
    // ──────────────────────────────────────────────────────────────
    private void SelectPeriod()
    {
        int minY = _allDraws.Count > 0 ? _allDraws.Min(d => d.Year) : 1958;
        int maxY = _allDraws.Count > 0 ? _allDraws.Max(d => d.Year) : 2025;

        Console.WriteLine($"  Налични години: {minY}–{maxY}");
        Console.WriteLine();

        int from = PromptYear($"  От година [{minY}]: ", minY, maxY);
        int to = PromptYear($"  До година [{maxY}]: ", minY, maxY);

        if (from > to) (from, to) = (to, from);

        _fromYear = from;
        _toYear = to;
        _filtered = _allDraws.Where(d => d.Year >= from && d.Year <= to).ToList();

        int count = ((List<Draw>)_filtered).Count;
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"  ✓ Заредени {count} тиража за периода {from}–{to}.");
        Console.ResetColor();
        WaitForKey();
    }

    // ──────────────────────────────────────────────────────────────
    // Option 2 – Top N numbers + heat map
    // ──────────────────────────────────────────────────────────────
    private void ShowTopNumbers()
    {
        if (!EnsurePeriodSelected()) return;

        int n = PromptPositiveInt("  Брой числа (N): ", 1, 49);

        var topN = Statistics.GetTopNNumbers(_filtered!, n);

        string title = $"  Топ {n} числа ({_fromYear}–{_toYear}):";
        Visualizer.ShowBarChart(title, topN);

        // Heat map uses ALL numbers in the period, not just top-N
        var allFreqs = Statistics.GetTopNNumbers(_filtered!, 49);
        Visualizer.ShowHeatMap(allFreqs, $"  Топлинна карта ({_fromYear}–{_toYear}):");

        WaitForKey();
    }

    // ──────────────────────────────────────────────────────────────
    // Option 3 – Hot pairs
    // ──────────────────────────────────────────────────────────────
    private void ShowHotPairs()
    {
        if (!EnsurePeriodSelected()) return;

        int n = PromptPositiveInt("  Брой двойки (N): ", 1, 200);

        var pairs = Statistics.GetHotPairs(_filtered!, n);

        Visualizer.ShowHotPairs(pairs, $"  Топ {n} горещи двойки ({_fromYear}–{_toYear}):");
        WaitForKey();
    }

    // ──────────────────────────────────────────────────────────────
    // Option 4 – Decade distribution
    // ──────────────────────────────────────────────────────────────
    private void ShowDecadeDistribution()
    {
        if (!EnsurePeriodSelected()) return;

        var dist = Statistics.GetDecadeDistribution(_filtered!);
        Visualizer.ShowDecadeDistribution(dist, $"  Разпределение по десетици ({_fromYear}–{_toYear}):");
        WaitForKey();
    }

    // ──────────────────────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────────────────────
    private bool EnsurePeriodSelected()
    {
        if (_filtered is not null) return true;

        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("  ⚠  Моля, първо изберете период с опция [1].");
        Console.ResetColor();
        WaitForKey();
        return false;
    }

    private static int PromptYear(string prompt, int min, int max)
    {
        while (true)
        {
            Console.Write(prompt);
            string? line = Console.ReadLine();
            if (int.TryParse(line, out int val) && val >= min && val <= max)
                return val;

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"  Невалидна стойност. Въведете цяло число между {min} и {max}.");
            Console.ResetColor();
        }
    }

    private static int PromptPositiveInt(string prompt, int min, int max)
    {
        while (true)
        {
            Console.Write(prompt);
            string? line = Console.ReadLine();
            if (int.TryParse(line, out int val) && val >= min && val <= max)
                return val;

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"  Невалидна стойност. Въведете цяло число между {min} и {max}.");
            Console.ResetColor();
        }
    }

    private static void WaitForKey()
    {
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.WriteLine("  Натиснете произволен клавиш за връщане към менюто...");
        Console.ResetColor();
        if (Console.IsInputRedirected)
            Console.ReadLine();
        else
            Console.ReadKey(intercept: true);
        Console.Clear();
    }
}
