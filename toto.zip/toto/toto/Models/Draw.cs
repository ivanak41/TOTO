namespace Toto.Models;

public record Draw(int Year, int DrawNumber, int[] Numbers);
