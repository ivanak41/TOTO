﻿using Toto.Services;
using Toto.UI;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.Clear();

Console.ForegroundColor = ConsoleColor.Cyan;
Console.WriteLine("  ============================================");
Console.WriteLine("              ТОТО АНАЛИЗАТОР");
Console.WriteLine("  ============================================");
Console.ResetColor();
Console.WriteLine();
Console.Write("  Зареждане на данни...");

var allDraws = await DataLoader.LoadAllDrawsAsync();
var drawList = allDraws.ToList();

Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine($" готово!");
Console.ResetColor();
Console.WriteLine($"  Заредени {drawList.Count} тиража " +
    $"({drawList.Min(d => d.Year)}–{drawList.Max(d => d.Year)}).");

System.Threading.Thread.Sleep(1200);
Console.Clear();

new Menu(drawList).Run();

Console.WriteLine();
Console.WriteLine("  До следващия път!");

